package com.kosta.sbproject.model;

public enum MemberRoleEnumType {
	MANAGER,ADMIN,USER
}
